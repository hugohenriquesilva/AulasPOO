import fatec.poo.model.Circulo;
import java.util.Scanner;

public class AplicCirculo 
{
   public static void main(String[] args) 
    {
       Scanner entrada = new Scanner (System.in);
       Circulo circ1 = new Circulo ();
       
       double medRaio;
       
       System.out.print("Digite o raio do círculo: ");
       medRaio = entrada.nextDouble();
       
       circ1.setRaio(medRaio);
       
       System.out.println("Medida da área é: " + circ1.calcArea());
       System.out.println("O perímetro do cículo é: " + circ1.calcPerimetro());
       System.out.println("O diâmetro do círculo é: " + circ1.calcDiametro());
    }
}
