/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482323031
 */
public class Exemplo1 {

    
    public static void main(String[] args) 
    {
      int idade;
      double peso;
      char sexo;
      String nome;
      
      idade = 34;
      peso = 78.5;
      sexo = 'F';
      nome = "Ana Beatriz";
      
      System.out.println("Idade: " + idade);
      System.out.println("Peso:" + peso);
      System.out.println("Sexo: " + sexo);
      System.out.println("Nome:" + nome);
    }
    
}
