/**
 *
 * @author 0030482323031
 */
public class Exemplo4
{ 
    public static void main(String[] args)
    {
       int cont;
       
        System.out.println("\t Tabuada do 7\n");
        cont = 1;
        while (cont <= 10)
        {
            System.out.println("7 * " + cont + " = " + 7 * cont);
            cont++;
        }
    }
    
}
