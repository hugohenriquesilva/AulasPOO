/**
 *
 * @author 0030482323031
 */
public class Exemplo 
{
    public static void main(String[] args) 
    {
       int tabNum[];
       int cont;
       
       tabNum = new int [3];
       
       tabNum[0] = 34;
       tabNum[1] = 18;
       tabNum[2] = 27;
       
       for(cont = 0; cont <3; cont ++)
       {
           System.out.println("Conteúdo de TabNum [" + cont + "] = ");
           System.out.println(tabNum[cont]);
       }
    }
}
