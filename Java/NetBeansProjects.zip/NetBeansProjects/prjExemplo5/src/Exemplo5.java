/**
 *
 * @author 0030482323031
 */
public class Exemplo5
{  
    public static void main(String[] args) 
    {
        int cont;
        
        System.out.println("\t Tabuada do 7\n");
        cont = 1;
        do 
        {
            System.out.println("7 * " + cont + " = " + 7 * cont);
            cont++;
        }
        while (cont <= 10);
    }
    
}
