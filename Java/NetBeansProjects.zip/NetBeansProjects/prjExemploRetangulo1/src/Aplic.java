
import fatec.poo.model.Retangulo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482323031
 */
public class Aplic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       Retangulo objRet;
       
       objRet = new Retangulo ();
       
       //Passagem de mensagens 
       objRet.setAltura(8.0);
       objRet.setBase(5.0);
        System.out.println("Medida da área: " + objRet.calcArea());
        System.out.println("Madida do perímetro " + objRet.calcPerimetro());
        
        System.out.println("Medida da altura" + objRet.getAltura());
        System.out.println("Medida da base" + objRet.getBase());
        System.out.println("A hipotenusa é: " + objRet.calDiagonal() + "\n");
        
         Retangulo objRet1 = new Retangulo();
        
       objRet1.setAltura(3.0);
       objRet1.setBase(4.0);
               
        System.out.println("Medida da altura" + objRet1.getAltura());
        System.out.println("Medida da base" + objRet1.getBase());
        System.out.println("A hipotenusa Ã©: " + objRet1.calDiagonal());
        
        System.out.println("Medida da Ã¡rea: " + objRet1.calcArea());
        System.out.println("Medida do perÃ­metro " + objRet1.calcPerimetro());
          
    }
    
}
