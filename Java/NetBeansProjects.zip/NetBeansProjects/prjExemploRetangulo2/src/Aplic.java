
import fatec.poo.model.Retangulo;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482323031
 */
public class Aplic {

     public static void main(String[] args)
    {
        Scanner entrada= new Scanner(System.in);
        Retangulo objRet = new Retangulo ();
        
        double medAlt, medBase;
        
        System.out.print("Digite a altura: ");
        medAlt = entrada.nextDouble();
        System.out.print("Digite a base: ");
        medBase = entrada.nextDouble();
        
       objRet.setAltura(medAlt);
       objRet.setBase(medBase);
        
        System.out.println("\nMedida da área: " + objRet.calcArea());
        System.out.println("Madida do perímetro " + objRet.calcPerimetro());
        
        System.out.println("Medida da altura" + objRet.getAltura());
        System.out.println("Medida da base" + objRet.getBase());
        System.out.println("A hipotenusa é: " + objRet.calDiagonal());
    }
    
}
