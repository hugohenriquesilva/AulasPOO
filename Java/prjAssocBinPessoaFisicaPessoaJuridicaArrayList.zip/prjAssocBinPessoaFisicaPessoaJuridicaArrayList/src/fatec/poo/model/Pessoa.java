package fatec.poo.model;

import java.util.ArrayList;

/**
 *
 * @author Dimas
 */
public abstract class Pessoa {
    private String nome;
    private int anoInscricao;
    private double totalCompras; 
    private ArrayList <PedidoCompra> pedidosCompra;
    private int numPed;
    
    public Pessoa(String n, int anoIns){
        nome = n;
        anoInscricao = anoIns;     
        pedidosCompra = new ArrayList<PedidoCompra>();       
    }
    
    abstract public double calcBonus(int anoAtual);
    
    public void addCompras(double val){
        totalCompras += val; //totalCompras = totalCompras + val
    }
    
    public String getNome() {
        return nome;
    }

    public int getAnoInscricao() {
        return anoInscricao;
    }

    public double getTotalCompras() {
        return totalCompras;
    }  

    public int getNumPed() {
        return numPed;
    }
    
    public void addPedidoCompra(PedidoCompra pc){
        pedidosCompra.add(pc);        
    }
}
