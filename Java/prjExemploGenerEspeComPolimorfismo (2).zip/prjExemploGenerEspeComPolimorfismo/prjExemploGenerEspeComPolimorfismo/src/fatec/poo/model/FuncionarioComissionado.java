/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.model;

/**
 *
 * @author 0030482323031
 */
public class FuncionarioComissionado extends Funcionario {
    
    private double salBase;
    private double taxaComissao;
    private double totalVendas;   
    public FuncionarioComissionado (int r, String n, String dtAdm, double txc){
        super(r, n, dtAdm);
        taxaComissao = txc;
    }
    public double calcSalBruto();
   
    }
    

