package fatec.poo.model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0030482323031
 */
public class FuncionarioHorista extends Funcionario {
    private double valHorTrab;
    private int qtdeHorTrab;
    
    public FuncionarioHorista (int r, String n, String dtAdm, double vht){
        super(r, n, dtAdm);
        valHorTrab = vht;
    }
    
    public void setQtdeHorTrab (int qht){
        qtdeHorTrab = qht;
    }
    
    public double calcSalBruto(){
        return (valHorTrab * qtdeHorTrab);
    }
    
    public double calcGratificacao(){
        return(0.075 * calcSalBruto());
    }
    
    public double calcSalLiquido(){//quando a suclasse tem o mesmo método de uma super classe, o que é o método
        //da subclasse
        return(super.calcSalLiquido() + calcGratificacao());        
    }
}
