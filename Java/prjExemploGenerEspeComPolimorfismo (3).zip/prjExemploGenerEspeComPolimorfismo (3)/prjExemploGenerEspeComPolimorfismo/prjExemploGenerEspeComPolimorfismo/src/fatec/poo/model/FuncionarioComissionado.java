/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.model;

import fatec.poo.model.Funcionario;

/**
 *
 * @author 0030482323031
 */
public class FuncionarioComissionado extends Funcionario {
    
    private double salBase;
    private double taxaComissao;
    private double totalVendas;   
    
    public FuncionarioComissionado (int r, String n, String dtAdm, double txc){
        super(r, n, dtAdm);
        taxaComissao = txc;
    }
    
    public void setSalBase(double salMinimo){
        salBase = salMinimo;
    }
    
    public double getSalBase(){
        return(salBase);
    }
    
    public double getTotalVendas(){
        return(totalVendas);
    }
    
    public double getTaxaComissao(){
        return (taxaComissao);
    } 
        
    public void setAddVendas (double valVenda){
        totalVendas = valVenda;
    }
    
    @Override
    public double calcSalBruto(){
        return (salBase + (taxaComissao * totalVendas));
     }
     
    public double calcGratificacao(){
        if (totalVendas < 5000){
            return 0;
        }
        else if (totalVendas >= 5000 && totalVendas < 10000){
           return (calcSalBruto() * 0.03);
        }   
        else {
            return (calcSalBruto() * 0.05);
        }    
              
    }
     
     public double calcSalLiq (){
         return (calcSalBruto() - super.calcDesconto() + calcGratificacao());
     }
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    public double calcSalBruto(){
        return (salBase + (taxaComissao * totalVendas));
    }
}
    

