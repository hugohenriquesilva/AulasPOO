
package fatec.poo.model;

import java.util.ArrayList;


public class Hospede  extends Pessoa{
    
  private String cpf;
  private double taxaDesconto;
  private Registro registro;
  private ArrayList<Registro> registros;

  
    public Hospede(String cpf, String nome) {
        super(nome);
        this.cpf = cpf;
        this.registros = new ArrayList<>();
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getTaxaDesconto() {
        return taxaDesconto;
    }

    public void setTaxaDesconto(double taxaDesconto) {
        this.taxaDesconto = taxaDesconto/100;
    }
    
    public void addRegistro(Registro r){
        this.registros.add(r);
        r.setHospede(this);
    }
    
       
    
}
