
package fatec.poo.model;

public class Quarto {
    
    
  private  int numero;
  private  String tipo;
 private   boolean situacao;
  private  double valorDiaria;
 private   double totalFaturado;
 private Registro registro;

    public Quarto(int numero, String tipo, double valorDiaria) {
        this.numero = numero;
        this.tipo = tipo;
        this.valorDiaria = valorDiaria;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isSituacao() {
        return situacao;
    }

    public void setSituacao(boolean situacao) {
        this.situacao = situacao;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

    public double getTotalFaturado() {
        return totalFaturado;
    }

    public void setTotalFaturado(double totalFaturado) {
        this.totalFaturado = totalFaturado;
    }
    
    public void reservar (boolean situacao)
    {
        this.situacao = true;
    }
    
    public double liberar (int numero)
    {
        get
    }
    
    
     //retorna o endereço de um objeto
    //da classe Departamento
    public Registro getRegistro() {
        return registro;
    }

    //tem como parâmetro de entrada o endereço
    //de um objeto da classe Departamento
    public void setRegistro(Registro registro) {
        this.registro = registro;
    }
    
   
    public int dias( LocalDate entrada, LocalDate saida){
    
    
    }
    
}
