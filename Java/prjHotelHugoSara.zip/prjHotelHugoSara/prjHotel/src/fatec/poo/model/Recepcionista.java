
package fatec.poo.model;



public class Recepcionista  extends Pessoa{
    
  private int  RegFunc;
 private  String turno;

  

    public Recepcionista(int RegFunc, String nome) {
        super(nome);
        this.RegFunc = RegFunc;
    }

    public int getRegFunc() {
        return RegFunc;
    }

    public void setRegFunc(int RegFunc) {
        this.RegFunc = RegFunc;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }
   
   
    
}
