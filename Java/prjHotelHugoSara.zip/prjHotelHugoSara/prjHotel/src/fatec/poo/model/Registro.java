
package fatec.poo.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;


public class Registro {    
    
   private int codigo;
    private LocalDate dataEntrada;
    private LocalDate dataSaida;
    private double valorHospedagem;
    private Hospede hospede;
    private Quarto quarto;
    private Recepcionista recepcionista;
    private ArrayList<ServicoQuarto> servicoQuarto;
  
    public Registro(int codigo, LocalDate dataEntrada, Recepcionista recepcionista) {
        this.codigo = codigo;
        this.dataEntrada = dataEntrada;
        this.recepcionista = recepcionista;
        this.servicoQuarto = new ArrayList<>();
    }
  
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public LocalDate getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(LocalDate dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public LocalDate getDataSaida() {
        return dataSaida;
    }
    
     public double getValorHospedagem() {
        return valorHospedagem;
    }
     
       public Hospede getHospede() {
        return hospede;
    }

    public void setHospede(Hospede hospede) {
        this.hospede = hospede;
    }

    public void setDataSaida(LocalDate dataSaida) {
        this.dataSaida = dataSaida;
    }

    public void setValorHospedagem(double valorHospedagem) {
        this.valorHospedagem = valorHospedagem;
    }

  public void addServicoQuarto(ServicoQuarto sq){
        this.servicoQuarto.add(sq);
    }
    
    public void reservarQuarto(Hospede hospede, Quarto quarto){
        quarto.reservar();
    }
    
    public double liberarQuarto(){
        
        if(!servicoQuarto.isEmpty()) {
            for (ServicoQuarto sq : this.servicoQuarto) {
                valorHospedagem += sq.getValor();
            }
        }
        
        valorHospedagem += quarto.liberar(dataSaida.getDayOfMonth() - dataEntrada.getDayOfMonth());
        return(valorHospedagem - (valorHospedagem * hospede.getTaxaDesconto()));
    }
}
  